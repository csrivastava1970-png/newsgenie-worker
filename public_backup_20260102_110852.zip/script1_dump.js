
/* === Editorial Extraction : Suggestions Panel + Transcript Auto-Ingest (Clean V3) === */
(function () {
  "use strict";

  // ---------------- utils ----------------
  function esc(s) {
    return String(s ?? "").replace(/[&<>"']/g, (m) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    }[m]));
  }
  function norm(s) { return String(s ?? "").replace(/\s+/g, " ").trim(); }
  function normKey(s) {
    return norm(s).toLowerCase()
      .replace(/[“”"']/g, "")
      .replace(/[^\p{L}\p{N}\s]/gu, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  // optional speaker→designation map
  window.__NG_SPEAKER_MAP = window.__NG_SPEAKER_MAP || {
    "किरण रिजिजू": "केंद्रीय मंत्री",
    "जयराम रमेश": "कांग्रेस नेता"
  };

  // ---------------- extraction helpers ----------------
  function guessSpeakerFromText(text) {
    const t = norm(text);

    // "नाम (पद): बयान..."
    const m2 = t.match(/^(.{2,40})\s*\((.{2,40})\)\s*[:：]\s*(.+)$/);
    if (m2) return { speaker: norm(m2[1]), designation: norm(m2[2]), text: norm(m2[3]) };

    // "नाम: बयान..."
    const m = t.match(/^([^:：]{2,40})\s*[:：]\s*(.+)$/);
    if (m) return { speaker: norm(m[1]), text: norm(m[2]) };

    // "नाम ने कहा/बताया... (कि) ..."
    const m3 = t.match(
      /^([^\s:：]{2,20}(?:\s+[^\s:：]{2,20}){0,2})\s+(?:ने\s+(?:कहा|बोले|बताया|आरोप\s+लगाया|दावा\s+किया|तंज\s+कसा)|का\s+कहना\s+है)\s*(?:कि\s*)?(.+)$/
    );
    if (m3) {
      const sp = norm(m3[1]);
      const rest = norm(m3[2] || "");
      if (sp && !/^(उन्होंने|उसने|हमने|आपने|इन्होंने|उनका|उसका)$/u.test(sp)) {
        return { speaker: sp, text: rest || t };
      }
    }

    return { text: t };
  }

  function scoreLine(line) {
    const t = (line.text || "").trim();
    const len = t.length;
    let score = 0;

    if (len >= 18 && len <= 140) score += 3;
    else if (len >= 10 && len <= 220) score += 1.5;
    else if (len < 8) score -= 4;
    else score -= 0.2;

    if (line.speaker) score += 1.6;
    if (/[“”"']/.test(t)) score += 1.2;
    if (/[?!]/.test(t)) score += 0.4;

    if (/(कहा|बोले|बताया|स्पष्ट|साफ|जवाब|तैयार|आरोप|तंज|सरकार|विपक्ष|जांच|सवाल|चुनाव|संसद|देश|जनता)/.test(t)) score += 2;
    if (/(नहीं|गलत|झूठ|सबूत|कार्रवाई|मांग|इस्तीफा|हमला|बचाव)/.test(t)) score += 1;
    if (/[0-9०-९]/.test(t)) score += 0.6;

    if (/(धन्यवाद|नमस्कार|स्वागत|आप देख रहे|देखिए|दोस्तों|चलिये|अब हम)/.test(t)) score -= 4;

    return score;
  }

  function extractReverieText(root) {
    if (!root) return "";
    if (typeof root === "string") return root.trim();

    const cands = [
      root.display_text, root.text,
      root.result?.display_text, root.result?.text,
      root.output?.display_text, root.output?.text,
      root.data?.display_text, root.data?.text,
      root.response?.display_text, root.response?.text,
      root.success && root.text ? root.text : null
    ];
    for (const c of cands) if (typeof c === "string" && c.trim()) return c.trim();
    return "";
  }

  function mapArrToLines(arr) {
    const out = [];
    for (const it of arr || []) {
      let txt = "";
      if (typeof it === "string") txt = it;
      else if (it && typeof it === "object") {
        txt = it.text || it.transcript || it.utterance || it.sentence || it.content || it.line || "";
      }
      txt = norm(txt);
      if (!txt) continue;

      const g = guessSpeakerFromText(txt);
      let speaker = norm(g.speaker || it?.speaker || it?.name || "");
      let designation = norm(g.designation || it?.designation || it?.title || "");
      let text = norm(g.text || txt);

      if (speaker && !designation) designation = window.__NG_SPEAKER_MAP[speaker] || "";

      out.push({ speaker, designation, text });
    }
    return out;
  }

  function looksLikeTranscriptArr(arr) {
    let hits = 0, totalLen = 0;
    for (const it of arr || []) {
      const txt = (typeof it === "string")
        ? it
        : (it?.text || it?.transcript || it?.utterance || it?.sentence || it?.content || it?.line);
      if (typeof txt === "string" && txt.trim()) {
        hits++;
        totalLen += txt.trim().length;
      }
    }
    const avg = hits ? totalLen / hits : 0;
    return hits >= 2 && avg >= 10;
  }

  function collectCandidateLines(root, opts) {
    const maxNodes = Number(opts?.maxNodes || 9000);

    // Prefer full text
    const fullText = extractReverieText(root);
    if (fullText) {
      const normalized = String(fullText)
        .replace(/\r/g, "\n")
        .replace(/[ \t]+/g, " ")
        .replace(/\n{3,}/g, "\n\n")
        .replace(/([।.?!])\s+/g, "$1\n")
        .trim();

      const parts = normalized
        .split("\n")
        .map(s => (s || "").trim())
        .filter(s => s.length >= 12)
        .slice(0, 80);

      return parts.map(p => {
        const g = guessSpeakerFromText(p);
        const speaker = norm(g.speaker || "");
        const designation = norm(g.designation || (speaker ? (window.__NG_SPEAKER_MAP[speaker] || "") : ""));
        const text = norm(g.text || p);
        return { speaker, designation, text };
      });
    }

    // Direct arrays
    const directCandidates = [];
    if (Array.isArray(root?.segments)) directCandidates.push(root.segments);
    if (Array.isArray(root?.result?.segments)) directCandidates.push(root.result.segments);
    if (Array.isArray(root?.data?.segments)) directCandidates.push(root.data.segments);
    if (Array.isArray(root?.utterances)) directCandidates.push(root.utterances);
    if (Array.isArray(root?.sentences)) directCandidates.push(root.sentences);
    if (Array.isArray(root?.results)) directCandidates.push(root.results);

    for (const arr of directCandidates) {
      if (Array.isArray(arr) && looksLikeTranscriptArr(arr)) return mapArrToLines(arr);
    }

    // BFS scan for best transcript-like array
    const queue = [root];
    let nodes = 0;
    const arrays = [];

    while (queue.length && nodes < maxNodes) {
      const v = queue.shift();
      nodes++;
      if (!v) continue;

      if (Array.isArray(v)) {
        if (looksLikeTranscriptArr(v)) arrays.push(v);
        for (const it of v) if (it && typeof it === "object") queue.push(it);
        continue;
      }
      if (typeof v === "object") {
        for (const k in v) {
          if (!Object.prototype.hasOwnProperty.call(v, k)) continue;
          const it = v[k];
          if (it && typeof it === "object") queue.push(it);
        }
      }
    }

    return mapArrToLines(arrays[0] || []);
  }

  function pickBestLines(lines, min = 6, max = 10) {
    const seenText = new Set();
    const bestPerSpeaker = new Map();
    const rest = [];

    for (const ln of (lines || [])) {
      const tKey = normKey(ln.text);
      if (!tKey || tKey.length < 8) continue;
      if (seenText.has(tKey)) continue;
      seenText.add(tKey);

      const scored = { ...ln, __score: scoreLine(ln) };
      if (scored.__score < -2.5) continue;

      const sp = norm(scored.speaker);
      if (sp) {
        const prev = bestPerSpeaker.get(sp);
        if (!prev || scored.__score > prev.__score) bestPerSpeaker.set(sp, scored);
        else rest.push(scored);
      } else {
        rest.push(scored);
      }
    }

    const picked = Array.from(bestPerSpeaker.values()).sort((a, b) => b.__score - a.__score);
    rest.sort((a, b) => b.__score - a.__score);

    for (const r of rest) {
      if (picked.length >= max) break;
      picked.push(r);
    }
    return picked.slice(0, Math.max(min, Math.min(max, picked.length)));
  }

  // ---------------- BYTES helpers (used by push) ----------------
  function getAddByteButton() {
    return (
      document.getElementById("addByteBtn") ||
      document.getElementById("add-byte") ||
      document.querySelector('[data-action="add-byte"]')
    );
  }

  function getByteFields() {
    const wrap = document.getElementById("bytesWrap") || document;
    const speakers = [...wrap.querySelectorAll('input[name="byte_speaker[]"]')];
    const desigs   = [...wrap.querySelectorAll('input[name="byte_designation[]"]')];
    const texts    = [...wrap.querySelectorAll('textarea[name="byte_text[]"], input[name="byte_text[]"]')];
    return { wrap, speakers, desigs, texts };
  }

  function ensureByteRows(targetCount) {
    const addBtn = getAddByteButton();
    if (!addBtn) return;

    let safety = 40;
    while (safety-- > 0) {
      const { speakers } = getByteFields();
      if (speakers.length >= targetCount) break;

      if (typeof window.NG_addByteRow === "function") window.NG_addByteRow();
      else addBtn.click();
    }
  }

  function existingByteSet() {
    const { speakers, desigs, texts } = getByteFields();
    const set = new Set();
    const n = Math.max(speakers.length, desigs.length, texts.length);

    for (let i = 0; i < n; i++) {
      const sp = normKey(speakers[i]?.value || "");
      const ds = normKey(desigs[i]?.value || "");
      const tx = normKey(texts[i]?.value || "");
      if (sp || ds || tx) set.add(`${sp}|${ds}|${tx}`);
    }
    return set;
  }

  function findFirstEmptySlot() {
    const { speakers, desigs, texts } = getByteFields();
    const n = Math.max(speakers.length, desigs.length, texts.length);

    for (let i = 0; i < n; i++) {
      const sp = norm(speakers[i]?.value || "");
      const ds = norm(desigs[i]?.value || "");
      const tx = norm(texts[i]?.value || "");
      if (!sp && !ds && !tx) return i;
      if (!sp && !ds) return i;
    }
    return n;
  }

  function fillSlot(i, item) {
    ensureByteRows(i + 1);
    const f = getByteFields();
    if (f.speakers[i]) f.speakers[i].value = item?.speaker || "";
    if (f.desigs[i])   f.desigs[i].value   = item?.designation || "";
    if (f.texts[i])    f.texts[i].value    = item?.text || "";
  }

  // ---------------- UI init ----------------
function initEditorialExtraction() {
  if (window.__NG_EE_INIT_DONE) return;
  window.__NG_EE_INIT_DONE = true;

  const eeList  = document.getElementById("ee-list");
  const eeEmpty = document.getElementById("ee-empty");
  const btnPush = document.getElementById("ee-push");
  const btnClear= document.getElementById("ee-clear");

  if (!eeList || !btnPush || !btnClear) {
    console.warn("[EE] Missing ee-list/ee-push/ee-clear");
    return;
  }

  let suggestions = [];

  function showEmpty(on) {
    if (!eeEmpty) return;
    eeEmpty.style.display = on ? "block" : "none";
  }

  function updateButtons() {
    const total   = eeList.querySelectorAll('input[type="checkbox"][data-i]').length;
    const checked = eeList.querySelectorAll('input[type="checkbox"][data-i]:checked').length;
    btnPush.disabled  = (checked === 0);
    btnClear.disabled = (total === 0);
  }

  // --- Bytes helpers (bulletproof, DOM-driven) ---
  function bytesWrapEl() {
    return document.getElementById("bytesWrap") || document.getElementById("bytes-wrap");
  }

  function addByteButtonEl() {
    return (
      document.getElementById("addByteBtn") ||
      document.getElementById("add-byte") ||
      document.getElementById("addByte")
    );
  }

  function getByteInputs() {
    const wrap = bytesWrapEl();
    if (!wrap) return { sp: [], ds: [], tx: [] };
    const sp = Array.from(wrap.querySelectorAll('input[name="byte_speaker[]"]'));
    const ds = Array.from(wrap.querySelectorAll('input[name="byte_designation[]"]'));
    const tx = Array.from(wrap.querySelectorAll('textarea[name="byte_text[]"], input[name="byte_text[]"]'));
    return { sp, ds, tx };
  }

  function ensureByteRows(minRows) {
    let { sp, ds } = getByteInputs();
    let n = Math.max(sp.length, ds.length);
    let safety = 0;

    while (n < minRows && safety++ < 30) {
      if (typeof window.NG_addByteRow === "function") {
        window.NG_addByteRow();
      } else {
        const addBtn = addByteButtonEl();
        if (addBtn) addBtn.click();
        else break;
      }
      ({ sp, ds } = getByteInputs());
      n = Math.max(sp.length, ds.length);
    }
    return n;
  }

  function findFirstEmptySlot() {
    const { sp, ds } = getByteInputs();
    const n = Math.max(sp.length, ds.length);
    for (let i = 0; i < n; i++) {
      const a = (sp[i]?.value || "").trim();
      const b = (ds[i]?.value || "").trim();
      if (!a && !b) return i;
    }
    return n; // append
  }

  function normKeyLocal(s) {
    return (s || "")
      .toString()
      .trim()
      .replace(/\s+/g, " ")
      .toLowerCase();
  }

  function existingByteSet() {
    const set = new Set();
    const { sp, ds, tx } = getByteInputs();
    const n = Math.max(sp.length, ds.length, tx.length);
    for (let i = 0; i < n; i++) {
      const speaker = (sp[i]?.value || "").trim();
      const desig   = (ds[i]?.value || "").trim();
      const text    = (tx[i]?.value || "").trim();
      if (!speaker && !desig && !text) continue;
      set.add(`${normKeyLocal(speaker)}|${normKeyLocal(desig)}|${normKeyLocal(text)}`);
    }
    return set;
  }

  // ✅ return true/false
  function fillSlot(slotIndex, item) {
    ensureByteRows(slotIndex + 1);

    const { sp, ds, tx } = getByteInputs();
    if (!sp[slotIndex] || !ds[slotIndex]) return false;

    const speaker = (item?.speaker || "").toString().trim();
    const desig   = (item?.designation || "").toString().trim();
    const text    = (item?.text || "").toString().trim();

    if (!speaker || !desig) return false;

    const spWas = (sp[slotIndex].value || "").trim();
    const dsWas = (ds[slotIndex].value || "").trim();

    // don't overwrite
    if (spWas || dsWas) return false;

    sp[slotIndex].value = speaker;
    ds[slotIndex].value = desig;

    if (tx && tx[slotIndex] && !((tx[slotIndex].value || "").trim()) && text) {
      tx[slotIndex].value = text;
    }

    // trigger input events
    try { sp[slotIndex].dispatchEvent(new Event("input", { bubbles: true })); } catch(e){}
    try { ds[slotIndex].dispatchEvent(new Event("input", { bubbles: true })); } catch(e){}
    if (tx && tx[slotIndex]) { try { tx[slotIndex].dispatchEvent(new Event("input", { bubbles: true })); } catch(e){} }

    return true;
  }

  function render(list) {
    suggestions = Array.isArray(list) ? list : [];

    // ✅ keep suggestions in memory for pushToBytes
    window.__NG_EE_SUGGEST = suggestions;
    window.__NG_EE_SUGGESTIONS = suggestions; // backward alias

    eeList.innerHTML = "";

    if (!suggestions.length) {
      showEmpty(true);
      btnPush.disabled = true;
      btnClear.disabled = true;
      return;
    }

    showEmpty(false);

    suggestions.forEach((b, i) => {
      const speaker = esc(b.speaker || "Unknown");
      const desig   = esc(b.designation || "");
      const text    = esc(b.text || "");

      const card = document.createElement("label");
      card.style.cssText =
        "border:1px solid #ddd;border-radius:12px;padding:10px;display:block;margin:10px 0;cursor:pointer;";

      card.innerHTML = `
        <div style="display:flex;gap:10px;align-items:flex-start;">
          <input type="checkbox" data-i="${i}" style="margin-top:3px;">
          <div style="flex:1;">
            <div style="font-weight:700;">${speaker}</div>
            <div style="opacity:.75;font-size:12px;margin-top:2px;">${desig}</div>
            <div style="margin-top:8px;line-height:1.35;">${text}</div>
          </div>
        </div>
      `;
      eeList.appendChild(card);
    });

    updateButtons();
  }

  function clearAll() {
    render([]);
  }

  function getCheckedIndices() {
    return [...eeList.querySelectorAll('input[type="checkbox"][data-i]:checked')]
      .map(cb => Number(cb.getAttribute("data-i")))
      .filter(n => Number.isFinite(n) && n >= 0);
  }

  function pushToBytes() {
    const idxs = getCheckedIndices();
    if (!idxs.length) return;

    const dupeSet = existingByteSet();
    const pushedRun = new Set();
    let pushed = 0;

    for (const idx of idxs) {
      const item = suggestions[idx];
      if (!item) continue;

      const speaker = (item.speaker || "").toString().trim();
      const desig   = (item.designation || "").toString().trim();
      const text    = (item.text || "").toString().trim();

      const key = `${normKeyLocal(speaker)}|${normKeyLocal(desig)}|${normKeyLocal(text)}`;

      // ✅ no duplicates: already in bytes OR already pushed in this click
      if (dupeSet.has(key) || pushedRun.has(key)) continue;

      // find next empty slot and ensure rows
      const slot = findFirstEmptySlot();
      ensureByteRows(slot + 1);

      const ok = fillSlot(slot, { speaker, designation: desig, text });

      // ✅ only if filled successfully: uncheck + count + add to sets
      if (ok) {
        const cb = eeList.querySelector(`input[type="checkbox"][data-i="${idx}"]`);
        if (cb) cb.checked = false;

        dupeSet.add(key);
        pushedRun.add(key);
        pushed++;
      }
    }

    if (pushed) console.log("[EE] Pushed to Bytes:", pushed);
    updateButtons();
  }

  // bind once
  if (!window.__NG_EE_WIRED) {
    window.__NG_EE_WIRED = true;

    eeList.addEventListener("change", updateButtons);

    btnPush.addEventListener("click", (e) => {
      e.preventDefault();
      pushToBytes();
    });

    btnClear.addEventListener("click", (e) => {
      e.preventDefault();
      clearAll();
    });
  }

  // expose renderer
  window.NG_setEditorialSuggestions = render;

  // initial empty
  render([]);
  console.log("[EE] initEditorialExtraction READY");
}

  // ---------------- ingest + hook NG_TRANSCRIPT ----------------
  window.NG_ingestTranscript = function (reverieJsonOrText) {
    const rawLines = collectCandidateLines(reverieJsonOrText, { maxNodes: 9000 });
    const best = pickBestLines(rawLines, 6, 10).map(x => ({
      speaker: x.speaker || "",
      designation: x.designation || "",
      text: x.text || ""
    }));

    // ✅ keep latest suggestions in memory (for pushToBytes fallback)
window.__NG_EE_SUGGEST = Array.isArray(best) ? best : [];

if (typeof window.NG_setEditorialSuggestions === "function") {
  window.NG_setEditorialSuggestions(best);
}

// ✅ after render, ensure push button state is correct
syncEePushBtn();

console.log("[EE] Transcript → suggestions:", best.length);
return best;


  (function hookTranscriptSetter() {
    if (window.__NG_TRANSCRIPT_HOOKED) return;
    window.__NG_TRANSCRIPT_HOOKED = true;

    let _t = window.NG_TRANSCRIPT;
    let _lastSig = "";

    function sigOf(v) {
      try {
        if (v == null) return "";
        if (typeof v === "string") return "str:" + v.slice(0, 120);
        return "obj:" + JSON.stringify(v).slice(0, 240);
      } catch {
        return "unk";
      }
    }

    function ingestSoon(v, reason) {
      const sig = sigOf(v);
      if (!sig || sig === _lastSig) return;
      _lastSig = sig;

      setTimeout(() => {
        try {
          if (typeof window.NG_ingestTranscript === "function") window.NG_ingestTranscript(v);
        } catch (e) {
          console.error("[EE] ingest error:", e);
        }
      }, 0);

      console.log("[EE] NG_TRANSCRIPT ingest (" + reason + ")");
    }

    try {
      Object.defineProperty(window, "NG_TRANSCRIPT", {
        configurable: true,
        get: function () { return _t; },
        set: function (v) { _t = v; ingestSoon(v, "setter"); }
      });
    } catch (e) {
      console.warn("[EE] NG_TRANSCRIPT hook failed (non-configurable).", e);
    }

    if (_t) ingestSoon(_t, "boot");
  })();

  // ---------------- Transcript JSON Loader ----------------
  (function initTranscriptJsonLoader() {
    const LS_KEY = "NG_REVERIE_TRANSCRIPT_JSON_V1";
    function $(id){ return document.getElementById(id); }

    function extractTranscriptText(obj) {
      if (typeof obj === "string") return obj;

      if (obj && typeof obj.display_text === "string" && obj.display_text.trim()) return obj.display_text;
      if (obj && typeof obj.text === "string" && obj.text.trim()) return obj.text;

      const cands = [obj?.result, obj?.output, obj?.data, obj?.transcript, obj?.transcription].filter(Boolean);
      for (const c of cands) {
        if (typeof c?.display_text === "string" && c.display_text.trim()) return c.display_text;
        if (typeof c?.text === "string" && c.text.trim()) return c.text;
      }

      const segs =
        obj?.segments || obj?.result?.segments || obj?.output?.segments || obj?.data?.segments ||
        obj?.utterances || obj?.result?.utterances || obj?.items;

      if (Array.isArray(segs) && segs.length) {
        const parts = segs.map(s =>
          (typeof s?.display_text === "string" && s.display_text.trim()) ? s.display_text :
          (typeof s?.text === "string" && s.text.trim()) ? s.text :
          (typeof s?.utterance === "string" && s.utterance.trim()) ? s.utterance :
          ""
        ).filter(Boolean);
        if (parts.length) return parts.join("\n");
      }

      return "";
    }

    function loadFromTextarea() {
      const ta = $("ta-transcript-json");
      if (!ta) return;

      const raw = (ta.value || "").trim();
      if (!raw) return;

      try { localStorage.setItem(LS_KEY, raw); } catch {}

      let parsed;
      try { parsed = JSON.parse(raw); } catch { parsed = raw; }

      const text = extractTranscriptText(parsed) || (typeof parsed === "string" ? parsed : "");
      window.NG_TRANSCRIPT = text; // ✅ sets extracted text
      console.log("[TL] NG_TRANSCRIPT set. chars:", (text || "").length);
    }

    function boot() {
      const ta = $("ta-transcript-json");
      const btn = $("btn-load-transcript-json");

      try {
        const saved = localStorage.getItem(LS_KEY);
        if (ta && saved && !ta.value.trim()) ta.value = saved;
      } catch {}

      if (btn && !btn.__NG_BOUND) {
        btn.__NG_BOUND = true;
        btn.addEventListener("click", (e) => {
          e.preventDefault();
          loadFromTextarea();
        });
      }
    }

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", boot, { once: true });
    } else {
      boot();
    }
})();  // ✅ close Transcript Loader IIFE


  // ---------------- export global + auto init ----------------
  window.initEditorialExtraction = initEditorialExtraction;

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initEditorialExtraction, { once: true });
  } else {
    initEditorialExtraction();
  }

})();


